Kvil Full History reviewer fixture

Fictional data only. This fixture grants no purchase entitlement.

## Contents

- One weekly 08:00–20:00 schedule with a unique UUID, effective 4 August 2026.
- 42 fictional daily reflections, 4 August–14 September 2026, in `Europe/Oslo`. Each note identifies it as a fictional reviewer entry.
- No weights, Health anchor, meal timestamps, dated schedule overrides, or breaks.
- iCloud sync, both reminders, Live Activities, weight logging, Health reads, and Health writes are explicitly disabled. Local Watch/widget schedule snapshots have no separate preference in the backup format.

The fixture uses the production encoder's default date format. Its anchor is 15 September 2026 at 00:00 UTC; no reflection timestamp is later than the anchor. It does not grant a purchase entitlement or bypass StoreKit.

## Import and review

1. Use a clean test installation. Import replaces local app data; export anything worth keeping first. Complete guided setup if necessary and leave iCloud sync off.

   Import preserves the device's existing iCloud choice. The fixture's disabled flag does not turn off sync on a device where it is already enabled.
2. Save `reviewer-demo.json` in Files. In Kvil, open Schedule or History, then Settings > Your data > Restore from a backup. Select the file and confirm Replace.
3. Before purchasing, History shows the latest seven days only. On 15 September the weekly recap has seven answers: two comfortable, two mixed, three difficult.
4. Open History > Explore full history and test the native purchase in the appropriate Apple test environment. After unlock, choose Month for 30 answers or All time for all 42. All time has 14 answers in each feeling category. Open an older reflection to check editing.
5. Test Restore Purchases using an eligible test purchase. Importing the fixture alone cannot establish restore eligibility.

Week and Month follow the device's current date, so their counts change after 15 September. All time retains all 42 entries. Refresh and revalidate the fixture before packaging if populated recent recaps are required on a later review date; do not ask reviewers to change the device clock.

